
export function Text(Props){

    return <p className="text">{Props.contenido}</p>

}