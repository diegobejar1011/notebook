
export function Title(Props){

   return <h1 className="title">{Props.name}</h1>
    
}