
export function Subtitle(Props){
    
    return <h2 className="subtitle">{Props.name}</h2>
}