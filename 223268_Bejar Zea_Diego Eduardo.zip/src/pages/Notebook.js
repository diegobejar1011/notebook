import '../css/index.css';
import {HomeNotes} from '../templates/HomeNotes';

export function Notebook(){
    return <HomeNotes />
}